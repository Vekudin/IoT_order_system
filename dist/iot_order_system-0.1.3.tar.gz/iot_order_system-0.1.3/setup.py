from setuptools import setup, find_packages
import pkginfo
import semver


version = '0.1.0'
version = semver.bump_patch(version)
version = semver.bump_patch(version)
version = semver.bump_patch(version)

setup(
    name="iot_order_system",
    version=version,
    packages=find_packages(),
    include_package_data=True,

    # This package_data include works only for 'install' and 'bdist' commands,
    # 'sdist' needs MANIFEST.in
    package_data={
        'tests': ['*.json', '*.txt']
    },

    author="Teodor Akov",
    install_requires=['boto3', 'pkginfo', 'gitpython', 'semver'],
    python_requires='>=3',

    classifiers=[
        'branch::master'
    ]


)
